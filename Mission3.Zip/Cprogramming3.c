#include <stdio.h>

int main()
{
	int val[2], sum;
	val[0] = 3;
	val[1] = 4;
	sum = val[0] + val[1];
	
	printf("%d\n", sum);
	
	return 0;
}